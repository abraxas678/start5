# v0.2.2

* Fix multiple argument bug introduced in v0.2.1

# v0.2.1

* Color directory/command yellow when running
* Fix bugs on Ubuntu

# v0.2.0

* Add `-s` to show status for use in profiles/prompts

# v0.1.1

* Fix q alias installation

# v0.1.0

* Initial release
